# AutoVPN (Android)

Клиент для вашей подписки: сам разбирает ссылку, группирует серверы по странам (до 10),
выбирает лучший сервер в стране (urltest) и раз в 6 часов сам обновляет список.
Протоколы: VLESS (+Reality), VMess, Trojan, Shadowsocks, Hysteria2, TUIC.

## Сборка
1. Нужно ядро `libbox.aar` (sing-box 1.11.x). В Maven его нет, его собирают из исходников:
   git clone https://github.com/SagerNet/sing-box && cd sing-box
   git checkout v1.11.x   # актуальная 1.11
   # соберите libbox для Android по инструкции в репозитории (нужны Go, Android SDK/NDK, gomobile)
   Готовый libbox.aar положите в app/libs/
2. Откройте папку AutoVPN в Android Studio, дождитесь Gradle Sync.
3. Build > Build APK(s), либо запустите на телефоне.

## Если не компилируется CoreService.kt
Сигнатуры PlatformInterface/Libbox.setup зависят от версии libbox. Alt+Enter ->
Implement members, заглушки возвращают false/null/пусто. Эталон: sing-box-for-android.

## Как работает
- Repo.kt: ссылка, кэш, обновление, выбор 10 стран
- Parser.kt: разбор vless/vmess/trojan/ss/hy2/tuic -> outbound sing-box, определение страны
- ConfigBuilder.kt: конфиг (по группе urltest на страну + selector)
- CoreService.kt: VpnService, запуск ядра, автообновление каждые 6 часов
- MainActivity.kt: экран (ссылка, обновить, подключить, выбор страны)
