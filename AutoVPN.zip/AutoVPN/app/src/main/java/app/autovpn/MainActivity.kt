package app.autovpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (it.resultCode == RESULT_OK) startCore() }

    private fun startCore() = startForegroundService(Intent(this, CoreService::class.java))

    private fun toggle() {
        if (CoreService.running) {
            startService(Intent(this, CoreService::class.java).setAction(CoreService.STOP))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) vpnPermission.launch(i) else startCore()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = Repo(this)
        setContent { MaterialTheme { Screen(repo) } }
    }

    @Composable
    private fun Screen(repo: Repo) {
        var url by remember { mutableStateOf(repo.url) }
        var groups by remember { mutableStateOf(repo.countries()) }
        var sel by remember { mutableStateOf(repo.country) }
        var msg by remember { mutableStateOf("") }
        val scope = rememberCoroutineScope()

        fun select(code: String) {
            sel = code; repo.country = code
            if (CoreService.running) startCore()   // перезапуск с новой страной
        }

        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = url, onValueChange = { url = it; repo.url = it },
                label = { Text("Ссылка на подписку") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    scope.launch {
                        msg = "Обновляю…"
                        msg = withContext(Dispatchers.IO) {
                            runCatching { repo.refresh() }.fold(
                                { if (it) "Список обновлён" else "Без изменений" },
                                { "Ошибка: ${it.message}" })
                        }
                        groups = repo.countries()
                    }
                }) { Text("Обновить") }
                Button(onClick = { toggle() }) {
                    Text(if (CoreService.running) "Отключить" else "Подключить")
                }
            }
            if (msg.isNotEmpty()) Text(msg)
            Text("Страна", style = MaterialTheme.typography.titleMedium)
            LazyColumn {
                item { CountryRow("🌐", "Авто (лучший сервер)", sel == "AUTO") { select("AUTO") } }
                items(groups) { (cc, nodes) ->
                    CountryRow(Country.flag(cc), "${Country.title(cc)} · ${nodes.size}", sel == cc) { select(cc) }
                }
            }
        }
    }

    @Composable
    private fun CountryRow(flag: String, title: String, selected: Boolean, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = selected, onClick = onClick)
            Text("$flag  $title")
        }
    }
}
