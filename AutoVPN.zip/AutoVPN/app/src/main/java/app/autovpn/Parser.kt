package app.autovpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.util.Locale

data class Node(val tag: String, val name: String, val country: String, val outbound: JSONObject)

/** Разбор подписки: vless, vmess, trojan, ss, hysteria2/hy2, tuic -> outbound'ы sing-box. */
object Parser {

    fun parse(body: String): List<Node> {
        val t = body.trim()
        val text = if (t.contains("://")) t else runCatching { b64(t) }.getOrDefault("")
        val res = ArrayList<Node>()
        text.lines().map { it.trim() }.filter { it.contains("://") }.forEach { line ->
            runCatching { parseLine(line, "n${res.size}") }.getOrNull()?.let { res += it }
        }
        return res
    }

    fun b64(s: String): String {
        var t = s.trim().replace('-', '+').replace('_', '/')
        while (t.length % 4 != 0) t += "="
        return String(Base64.decode(t, Base64.DEFAULT))
    }

    private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")

    private fun parseLine(line: String, tag: String): Node? =
        when (line.substringBefore("://").lowercase()) {
            "vmess" -> vmess(line, tag)
            "ss" -> ss(line, tag)
            "vless" -> uri("vless", line, tag)
            "trojan" -> uri("trojan", line, tag)
            "hysteria2", "hy2" -> uri("hysteria2", line, tag)
            "tuic" -> uri("tuic", line, tag)
            else -> null
        }

    private fun make(tag: String, name: String, host: String, o: JSONObject): Node {
        o.put("tag", tag)
        val n = name.ifBlank { host }
        return Node(tag, n, Country.detect(n), o)
    }

    private fun hostPort(hp: String): Pair<String, Int> {
        val clean = hp.trimEnd('/')
        return clean.substringBeforeLast(':').trim('[', ']') to clean.substringAfterLast(':').toInt()
    }

    private fun uri(proto: String, line: String, tag: String): Node {
        val rest = line.substringAfter("://")
        val name = dec(rest.substringAfter('#', ""))
        val noFrag = rest.substringBefore('#')
        val q = noFrag.substringAfter('?', "").split('&').filter { it.contains('=') }
            .associate { it.substringBefore('=') to dec(it.substringAfter('=')) }
        val main = noFrag.substringBefore('?')
        val user = main.substringBeforeLast('@')
        val (host, port) = hostPort(main.substringAfterLast('@'))
        val o = JSONObject().put("server", host).put("server_port", port)
        when (proto) {
            "vless" -> {
                o.put("type", "vless").put("uuid", user)
                q["flow"]?.takeIf { it.isNotEmpty() }?.let { o.put("flow", it) }
                tls(o, q, false)
                transport(o, q["type"], q["path"], q["host"], q["serviceName"])
            }
            "trojan" -> {
                o.put("type", "trojan").put("password", dec(user))
                tls(o, q, true)
                transport(o, q["type"], q["path"], q["host"], q["serviceName"])
            }
            "hysteria2" -> {
                o.put("type", "hysteria2").put("password", dec(user))
                q["obfs"]?.takeIf { it.isNotEmpty() }?.let {
                    o.put("obfs", JSONObject().put("type", it).put("password", q["obfs-password"] ?: ""))
                }
                tls(o, q, true)
            }
            "tuic" -> {
                o.put("type", "tuic").put("uuid", user.substringBefore(':'))
                    .put("password", user.substringAfter(':', ""))
                q["congestion_control"]?.let { o.put("congestion_control", it) }
                q["udp_relay_mode"]?.let { o.put("udp_relay_mode", it) }
                tls(o, q, true)
            }
        }
        return make(tag, name, host, o)
    }

    private fun vmess(line: String, tag: String): Node {
        val j = JSONObject(b64(line.removePrefix("vmess://").substringBefore('#')))
        val host = j.getString("add")
        val o = JSONObject().put("type", "vmess")
            .put("server", host)
            .put("server_port", j.get("port").toString().toInt())
            .put("uuid", j.getString("id"))
            .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0)
            .put("security", j.optString("scy").ifEmpty { "auto" })
        if (j.optString("tls") == "tls") {
            tls(o, mapOf(
                "security" to "tls",
                "sni" to j.optString("sni").ifEmpty { j.optString("host") },
                "alpn" to j.optString("alpn"),
                "fp" to j.optString("fp")
            ), false)
        }
        transport(o, j.optString("net"), j.optString("path"), j.optString("host"), j.optString("path"))
        return make(tag, j.optString("ps"), host, o)
    }

    private fun ss(line: String, tag: String): Node {
        val rest = line.removePrefix("ss://")
        val name = dec(rest.substringAfter('#', ""))
        val core = rest.substringBefore('#').substringBefore('?')
        val method: String; val pass: String; val hp: String
        if ('@' in core) {
            val ui = core.substringBeforeLast('@')
            val d = if (':' in ui) dec(ui) else b64(ui)
            method = d.substringBefore(':'); pass = d.substringAfter(':')
            hp = core.substringAfterLast('@')
        } else {
            val d = b64(core)
            method = d.substringBefore(':')
            val r = d.substringAfter(':')
            pass = r.substringBeforeLast('@'); hp = r.substringAfterLast('@')
        }
        val (host, port) = hostPort(hp)
        val o = JSONObject().put("type", "shadowsocks").put("server", host)
            .put("server_port", port).put("method", method).put("password", pass)
        return make(tag, name, host, o)
    }

    private fun tls(o: JSONObject, q: Map<String, String>, force: Boolean) {
        val sec = q["security"] ?: ""
        if (!(force || sec == "tls" || sec == "reality")) return
        val t = JSONObject().put("enabled", true)
        (q["sni"] ?: q["peer"])?.takeIf { it.isNotEmpty() }?.let { t.put("server_name", it) }
        if (q["allowInsecure"] == "1" || q["insecure"] == "1") t.put("insecure", true)
        q["alpn"]?.takeIf { it.isNotEmpty() }?.let { t.put("alpn", JSONArray(it.split(','))) }
        val fp = q["fp"]?.takeIf { it.isNotEmpty() }
        if (fp != null) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
        if (sec == "reality") {
            t.put("reality", JSONObject().put("enabled", true)
                .put("public_key", q["pbk"] ?: "").put("short_id", q["sid"] ?: ""))
            if (fp == null) t.put("utls", JSONObject().put("enabled", true).put("fingerprint", "chrome"))
        }
        o.put("tls", t)
    }

    private fun transport(o: JSONObject, type: String?, path: String?, host: String?, service: String?) {
        val t = JSONObject()
        when (type) {
            "ws" -> {
                t.put("type", "ws").put("path", path?.ifEmpty { "/" } ?: "/")
                if (!host.isNullOrEmpty()) t.put("headers", JSONObject().put("Host", host))
            }
            "grpc" -> t.put("type", "grpc").put("service_name", service?.ifEmpty { path } ?: path ?: "")
            "http", "h2" -> {
                t.put("type", "http").put("path", path?.ifEmpty { "/" } ?: "/")
                if (!host.isNullOrEmpty()) t.put("host", JSONArray(host.split(',')))
            }
            "httpupgrade" -> {
                t.put("type", "httpupgrade").put("path", path?.ifEmpty { "/" } ?: "/")
                if (!host.isNullOrEmpty()) t.put("host", host)
            }
            else -> return
        }
        o.put("transport", t)
    }
}

object Country {
    private val iso = Locale.getISOCountries().toSet()
    private val words = mapOf(
        "germany" to "DE", "германия" to "DE", "netherlands" to "NL", "нидерланды" to "NL",
        "holland" to "NL", "finland" to "FI", "финляндия" to "FI", "france" to "FR",
        "франция" to "FR", "united kingdom" to "GB", "england" to "GB", "великобритания" to "GB",
        "united states" to "US", "сша" to "US", "turkey" to "TR", "турция" to "TR",
        "poland" to "PL", "польша" to "PL", "sweden" to "SE", "швеция" to "SE",
        "kazakhstan" to "KZ", "казахстан" to "KZ", "japan" to "JP", "япония" to "JP",
        "singapore" to "SG", "сингапур" to "SG", "latvia" to "LV", "латвия" to "LV",
        "estonia" to "EE", "эстония" to "EE", "armenia" to "AM", "армения" to "AM",
        "georgia" to "GE", "грузия" to "GE", "switzerland" to "CH", "швейцария" to "CH",
        "canada" to "CA", "канада" to "CA"
    )

    fun detect(name: String): String {
        val cps = name.codePoints().toArray()
        for (i in 0 until cps.size - 1) {
            if (cps[i] in 0x1F1E6..0x1F1FF && cps[i + 1] in 0x1F1E6..0x1F1FF) {
                val c = "" + (cps[i] - 0x1F1E6 + 65).toChar() + (cps[i + 1] - 0x1F1E6 + 65).toChar()
                if (c in iso) return c
            }
        }
        val low = name.lowercase()
        words.entries.firstOrNull { low.contains(it.key) }?.let { return it.value }
        name.split(Regex("[^A-Za-z]+")).firstOrNull { it.length == 2 && it == it.uppercase() && it in iso }
            ?.let { return it }
        return "XX"
    }

    fun flag(c: String) =
        if (c == "XX") "🌐" else c.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")

    fun title(c: String) =
        if (c == "XX") "Другое" else Locale("", c).getDisplayCountry(Locale("ru"))
}
