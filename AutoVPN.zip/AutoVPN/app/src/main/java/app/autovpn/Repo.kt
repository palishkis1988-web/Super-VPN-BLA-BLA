package app.autovpn

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL

/** Хранит ссылку подписки, выбор страны и кэш списка серверов. */
class Repo(ctx: Context) {
    private val sp = ctx.getSharedPreferences("autovpn", Context.MODE_PRIVATE)

    var url: String
        get() = sp.getString("url", "") ?: ""
        set(v) { sp.edit().putString("url", v.trim()).apply() }

    /** "AUTO" или код страны, например "DE". */
    var country: String
        get() = sp.getString("country", "AUTO") ?: "AUTO"
        set(v) { sp.edit().putString("country", v).apply() }

    private fun cached() = sp.getString("body", "") ?: ""

    /** Скачивает подписку. true, если список изменился. Бросает исключение при ошибке сети. */
    fun refresh(): Boolean {
        require(url.startsWith("http")) { "Не указана ссылка подписки" }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "v2rayNG/1.8.5")
        val body = try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
        require(Parser.parse(body).isNotEmpty()) { "В подписке нет поддерживаемых серверов" }
        val changed = body != cached()
        if (changed) sp.edit().putString("body", body).apply()
        return changed
    }

    fun nodes(): List<Node> = Parser.parse(cached())

    /** До 10 стран с наибольшим числом серверов, по 15 серверов на страну. */
    fun countries(max: Int = 10): List<Pair<String, List<Node>>> =
        nodes().groupBy { it.country }.entries
            .sortedByDescending { it.value.size }
            .take(max)
            .map { it.key to it.value.take(15) }
}
