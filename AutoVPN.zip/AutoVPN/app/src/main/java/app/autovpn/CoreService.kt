package app.autovpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.nekohasekai.libbox.*
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * VPN-сервис: поднимает sing-box (libbox) и раз в 6 часов сам обновляет список серверов.
 *
 * ВАЖНО: интерфейс PlatformInterface и Libbox.setup() меняются от версии к версии libbox.
 * Если IDE подчёркивает красным, нажмите Alt+Enter -> "Implement members" и верните
 * заглушки (false / null / пусто), либо сверьтесь с реализацией в sing-box-for-android.
 */
class CoreService : VpnService(), PlatformInterface {

    companion object {
        const val STOP = "app.autovpn.STOP"
        var running by mutableStateOf(false)
    }

    private var box: BoxService? = null
    private var updater: ScheduledExecutorService? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            Thread { stopCore(); stopSelf() }.start()
            return START_NOT_STICKY
        }
        startForeground(1, notification("Подключение…"))
        Thread { startCore(refresh = true) }.start()
        return START_STICKY
    }

    @Synchronized
    private fun startCore(refresh: Boolean) {
        stopCore()
        val repo = Repo(this)
        try {
            if (refresh) runCatching { repo.refresh() }   // нет сети - берём кэш
            val config = ConfigBuilder.build(repo.countries(), repo.country)
            val dir = filesDir.absolutePath
            Libbox.setup(SetupOptions().also {
                it.basePath = dir; it.workingPath = dir; it.tempPath = cacheDir.absolutePath
            })
            box = Libbox.newService(config, this).also { it.start() }
            running = true
            updater = Executors.newSingleThreadScheduledExecutor().also { ex ->
                ex.scheduleWithFixedDelay({
                    if (runCatching { repo.refresh() }.getOrDefault(false)) {
                        Thread { startCore(refresh = false) }.start()   // новый список -> перезапуск
                    }
                }, 6, 6, TimeUnit.HOURS)
            }
            notify("Подключено: ${if (repo.country == "AUTO") "авто" else Country.title(repo.country)}")
        } catch (e: Throwable) {
            Log.e("AutoVPN", "start failed", e)
            notify("Ошибка: ${e.message}")
            running = false
        }
    }

    @Synchronized
    private fun stopCore() {
        updater?.shutdownNow(); updater = null
        runCatching { box?.close() }; box = null
        running = false
    }

    override fun onDestroy() { stopCore(); super.onDestroy() }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "vpn")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("AutoVPN").setContentText(text).setOngoing(true).build()
    }

    private fun notify(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, notification(text))

    // ---------- PlatformInterface ----------

    override fun openTun(options: TunOptions): Int {
        val b = Builder().setSession("AutoVPN").setMtu(9000)
            .addAddress("172.19.0.1", 30).addAddress("fdfe:dcba:9876::1", 126)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
            .addDnsServer("172.19.0.2")
        b.addDisallowedApplication(packageName)   // само приложение ходит мимо VPN (обновление подписки)
        val pfd = b.establish() ?: error("Не удалось создать VPN-интерфейс")
        return pfd.detachFd()
    }

    override fun usePlatformAutoDetectInterfaceControl() = true
    override fun autoDetectInterfaceControl(fd: Int) { protect(fd) }
    override fun writeLog(message: String) { Log.i("sing-box", message) }
    override fun useProcFS() = Build.VERSION.SDK_INT < 29
    override fun findConnectionOwner(
        ipProtocol: Int, sourceAddress: String, sourcePort: Int,
        destinationAddress: String, destinationPort: Int
    ): Int = -1
    override fun packageNameByUid(uid: Int) = ""
    override fun uidByPackageName(packageName: String) = 0
    override fun usePlatformDefaultInterfaceMonitor() = false
    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {}
    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {}
    override fun usePlatformInterfaceGetter() = false
    override fun getInterfaces(): NetworkInterfaceIterator = throw UnsupportedOperationException()
    override fun underNetworkExtension() = false
    override fun includeAllNetworks() = false
    override fun clearDNSCache() {}
    override fun readWIFIState(): WIFIState? = null
    override fun systemCertificates(): StringIterator? = null
    override fun sendNotification(notification: io.nekohasekai.libbox.Notification) {}
}
