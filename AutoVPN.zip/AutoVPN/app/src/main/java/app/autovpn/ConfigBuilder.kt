package app.autovpn

import org.json.JSONArray
import org.json.JSONObject

/** Собирает конфиг sing-box (формат 1.11.x). */
object ConfigBuilder {

    private fun arr(list: List<String>) = JSONArray(list)

    private fun urltest(tag: String, outs: List<String>) = JSONObject()
        .put("type", "urltest").put("tag", tag).put("outbounds", arr(outs))
        .put("url", "https://www.gstatic.com/generate_204")
        .put("interval", "5m").put("tolerance", 50).put("idle_timeout", "30m")

    fun build(groups: List<Pair<String, List<Node>>>, selected: String): String {
        require(groups.isNotEmpty()) { "Нет серверов. Обновите подписку." }
        val outs = JSONArray()
        val groupTags = ArrayList<String>()
        val allTags = ArrayList<String>()

        for ((cc, nodes) in groups) {
            val tag = "c-$cc"
            groupTags += tag
            allTags += nodes.map { it.tag }
            outs.put(urltest(tag, nodes.map { it.tag }))
        }
        outs.put(urltest("auto", allTags))
        val default = if ("c-$selected" in groupTags) "c-$selected" else "auto"
        outs.put(JSONObject().put("type", "selector").put("tag", "proxy")
            .put("outbounds", arr(listOf("auto") + groupTags)).put("default", default))
        groups.forEach { (_, nodes) -> nodes.forEach { outs.put(it.outbound) } }
        outs.put(JSONObject().put("type", "direct").put("tag", "direct"))

        val cfg = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", JSONObject()
                .put("servers", JSONArray()
                    .put(JSONObject().put("tag", "remote").put("address", "tls://1.1.1.1").put("detour", "proxy"))
                    .put(JSONObject().put("tag", "local").put("address", "local")))
                .put("rules", JSONArray().put(JSONObject()
                    .put("outbound", JSONArray().put("any")).put("server", "local")))
                .put("final", "remote"))
            .put("inbounds", JSONArray().put(JSONObject()
                .put("type", "tun").put("tag", "tun-in")
                .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
                .put("auto_route", true).put("stack", "mixed")))
            .put("outbounds", outs)
            .put("route", JSONObject()
                .put("auto_detect_interface", false)
                .put("final", "proxy")
                .put("rules", JSONArray()
                    .put(JSONObject().put("action", "sniff"))
                    .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))))
        return cfg.toString()
    }
}
